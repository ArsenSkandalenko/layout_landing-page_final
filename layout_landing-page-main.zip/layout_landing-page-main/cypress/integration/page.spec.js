'use strict';

// TODO: edit it
describe('Page', () => {
  it('should be visitable', () => {
    cy.visit('/');
  });
});
